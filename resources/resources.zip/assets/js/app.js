
// require('./bootstrap');

// window.Vue = require('vue');


// Vue.component('example', require('./components/Example.vue'));

// const app = new Vue({
//     el: '#app'
// });

$(document).ready(function() {

	$('.alert-msg').fadeOut(5000);

});

